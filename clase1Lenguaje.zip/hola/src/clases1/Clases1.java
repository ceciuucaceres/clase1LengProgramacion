
package clases1;
import java.util.Scanner;

public class Clases1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int sumaEdadesMayores = 0;
        int cantidadMayores = 0;
        int sumaEdadesMenores = 0;
        int cantidadMenores = 0;

        for (int i = 0; i < 5; i++) {
            System.out.print("Ingrese la edad de la persona " + (i + 1) + ": ");
            int edad = scanner.nextInt();

            if (edad >= 18) {
                sumaEdadesMayores += edad;
                cantidadMayores++;
            } else {
                sumaEdadesMenores += edad;
                cantidadMenores++;
            }
        }

        double promedioMayores = cantidadMayores > 0 ? (double) sumaEdadesMayores / cantidadMayores : 0;
        double promedioMenores = cantidadMenores > 0 ? (double) sumaEdadesMenores / cantidadMenores : 0;

        System.out.println("Promedio de edades de mayores de edad: " + promedioMayores);
        System.out.println("Promedio de edades de menores de edad: " + promedioMenores);

        scanner.close();
    }
}
